#include <RTMB_stubs.cpp>

// extern "C" {
//   void rtmb_set_shared_pointers();
//   
//   void R_init_spa2(DllInfo *dll) {
//     R_registerRoutines(dll, NULL, CallEntries, NULL, NULL);
//     R_useDynamicSymbols(dll, FALSE);
//     rtmb_set_shared_pointers();  
//   }
// }
