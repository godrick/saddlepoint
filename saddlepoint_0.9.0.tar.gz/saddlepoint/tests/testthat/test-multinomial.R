# # tests/testthat/test-multinomial.R
# 
# library(testthat)
# 
# test_that("MultinomialCGF basics", {
#   # 1) We have a ready-to-use CGF object: MultinomialCGF
#   expect_true(inherits(MultinomialCGF, "CGF"))  # Should be an R6 object inheriting from CGF
#   
#   # 2) Evaluate K, K1, etc. on a small example
#   tvec <- c(0.1, -0.2, 0.05)
#   param <- c(10, 2, 3, 5)  # total=10, odds=(2,3,5)
#   
#   # Check K
#   K_val <- MultinomialCGF$K(tvec, param)
#   expect_true(is.numeric(K_val))
#   expect_length(K_val, 1)
#   
#   # Check K1
#   K1_val <- MultinomialCGF$K1(tvec, param)
#   expect_true(is.numeric(K1_val))
#   expect_length(K1_val, length(tvec))
#   
#   # Check K2
#   K2_val <- MultinomialCGF$K2(tvec, param)
#   expect_true(is.matrix(K2_val))
#   expect_equal(nrow(K2_val), length(tvec))
#   expect_equal(ncol(K2_val), length(tvec))
#   
#   # K3, K4 - just see if they run without error; we can do a quick numeric check
#   v1 <- c(1, 0, 0)
#   v2 <- c(0, 1, 0)
#   v3 <- c(0, 0, 1)
#   v4 <- c(1, 1, 1)
#   
#   K3_val <- MultinomialCGF$K3operator(tvec, v1, v2, v3, param)
#   expect_true(is.numeric(K3_val))
#   expect_length(K3_val, 1)
#   
#   K4_val <- MultinomialCGF$K4operator(tvec, v1, v2, v3, v4, param)
#   expect_true(is.numeric(K4_val))
#   expect_length(K4_val, 1)
# })
# 
# test_that("MultinomialModelCGF param-based usage", {
#   # Suppose we define a param-based approach:
#   #   Nfun(theta) = first element,
#   #   probfun(theta) = the rest are probabilities
#   Nfun <- function(th) th[1]
#   probfun <- function(th) th[-1]
#   
#   # We create a param-based CGF
#   cgf_param <- MultinomialModelCGF(
#     N = Nfun,
#     prob_vec = probfun,
#     iidReps = 1  # single-block
#   )
#   
#   expect_true(inherits(cgf_param, "CGF"))
#   
#   # Evaluate K at tvec + param
#   tvec <- c(0.05, -0.1)
#   param <- c(10, 0.4, 0.6)
#   
#   outK <- cgf_param$K(tvec, param)
#   expect_true(is.numeric(outK))
#   
#   # Now test iidReps>1 usage
#   cgf_param_3 <- MultinomialModelCGF(
#     N = Nfun,
#     prob_vec = probfun,
#     iidReps = 3
#   )
#   # This should yield a block-replicated CGF, dimension of tvec is 3*d.
#   
#   # A quick sanity check: length(tvec) must be multiple of 3
#   param_iid <- c(10, 2,3,5)
#   # let's do a 2-cat dimension => actually param says d=2? or 3?
#   # We can do a quick call:
#   tvec2 <- c(0.1, 0.2, -0.2, -0.1, 0.05, 0.05) # length=6 for 2-categories repeated 3 times
#   outK2 <- cgf_param_3$K(tvec2, param_iid)
#   expect_true(is.numeric(outK2))
#   
#   # If dimension mismatch, it should error, which you can test:
#   expect_error(cgf_param_3$K(c(0.1,0.2), param_iid),
#                regexp="length.*multiple.*")  # or your chosen error message
# })
# 
# test_that("Override checks in createMultinomialFamilyCGF", {
#   # We'll supply a custom K_func to override the child's default.
#   
#   custom_K <- function(tvec, param) {
#     # silly override: just sum tvec for demonstration
#     sum(tvec) + sum(param)
#   }
#   
#   cgf_custom <- createMultinomialFamilyCGF(
#     K_func = custom_K
#   )
#   
#   # Now cgf_custom$K(...) should call 'custom_K'
#   val <- cgf_custom$K(c(0.1,0.2), c(10, 2, 3))
#   expect_equal(val, 0.3 + 15)  # sum(tvec)=0.3, sum(param)=10+2+3=15
#   
#   # Meanwhile, K1, K2, etc. come from the default child methods
#   k1_val <- cgf_custom$K1(c(0.1, 0.2), c(10, 2, 3))
#   expect_true(is.numeric(k1_val))
#   expect_length(k1_val, 2)
# })
# 
