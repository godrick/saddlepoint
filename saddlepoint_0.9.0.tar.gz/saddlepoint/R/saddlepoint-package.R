#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @import RTMB
#' @useDynLib saddlepoint, .registration = TRUE
## usethis namespace: end
NULL
