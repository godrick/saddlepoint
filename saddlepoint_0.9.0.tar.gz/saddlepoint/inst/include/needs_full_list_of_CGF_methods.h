// Include this file in any place where it is important to match with every supported CGF method, including those with default behaviour
// If an additional method is added, introduce an error using the following lines, and track where this error is included
// Do not add a header include guard for this file, as it is designed to be included multiple times at multiple locations

//#pragma("List of supported CGF methods has increased")
//"List of supported CGF methods has increased".new_method_name();
